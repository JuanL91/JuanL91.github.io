# AulaGestión RD V8 · Edición compartible

Este paquete contiene una copia limpia de AulaGestión RD V8 para instalar, revisar o adaptar en otro equipo.

## Funciones principales
- Modalidades, grados, secciones, materias y módulos formativos.
- Pegado masivo de estudiantes por grupo.
- Calendario escolar y control de fechas no lectivas.
- Asistencia P/A/T/E, historial y reporte mensual matricial.
- Asistencia vinculada a la materia o módulo.
- Técnico Profesional por RA: C.R.A., RP1, RP2, ponderación y resultados.
- Artes/Académica por siete competencias, P1-P4, PC1-PC4 y RPG.
- Recuperación pedagógica, completiva, extraordinaria y especiales.
- Instrumentos interactivos, metacognición, bitácora y convivencia.
- Reportes imprimibles/PDF y exportación Excel.
- IndexedDB local-first, respaldo JSON, Google Drive y OneDrive opcionales.

## Privacidad
Esta copia NO contiene el Client ID de Google de la instalación original, el hash de la cuenta original, Client Secret, la lista real de estudiantes precargada ni respaldos personales.

## Inicio en Windows
1. Descomprime el ZIP.
2. Configura `config.js`.
3. Ejecuta `INICIAR_AULAGESTION_WINDOWS.bat`.
4. Se abrirá `http://localhost:5500`.
5. Mantén abierta la ventana del servidor mientras uses la app.

## Configurar Google
1. Crea tu propio proyecto en Google Cloud.
2. Habilita Google Drive API.
3. Crea un OAuth 2.0 Client ID de tipo Aplicación web.
4. Agrega `http://localhost:5500` como Origen autorizado de JavaScript.
5. Copia el Client ID en `config.js`.
6. Abre `GENERAR_HASH_EMAIL.html`, genera el SHA-256 de tu correo y agrégalo en `authorizedUsers`.

Ejemplo de `config.js`:

    window.AULAGESTION_CONFIG = {
      googleClientId: 'TU_CLIENT_ID.apps.googleusercontent.com',
      authorizedUsers: [
        { hash: 'SHA256_DEL_CORREO', role: 'Administrador' }
      ]
    };

No uses un Client Secret dentro de una aplicación web estática.

## GitHub Pages
Si publicas la app, agrega tu origen `https://tuusuario.github.io` en Google OAuth. Para OneDrive registra como SPA la URL completa de la carpeta publicada, terminada en `/`.

## Datos
IndexedDB es la fuente local principal. Drive/OneDrive actúan como respaldo/sincronización opcional. Cada origen web tiene su propia base local.

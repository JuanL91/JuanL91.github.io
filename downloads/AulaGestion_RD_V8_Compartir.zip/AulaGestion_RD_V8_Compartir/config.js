// AulaGestión RD V8 · Configuración de la instalación
// Coloca aquí TU propio OAuth Client ID de Google.
// Genera el SHA-256 de cada correo autorizado con GENERAR_HASH_EMAIL.html.
// No coloques Client Secret: una SPA no debe incluir secretos.
window.AULAGESTION_CONFIG = {
  googleClientId: '',
  authorizedUsers: [
    // { hash: 'PEGA_AQUI_EL_SHA256_DEL_CORREO', role: 'Administrador' }
  ]
};

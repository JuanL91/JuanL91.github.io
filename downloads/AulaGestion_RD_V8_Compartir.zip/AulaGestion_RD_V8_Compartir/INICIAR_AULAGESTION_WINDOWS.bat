@echo off
cd /d %~dp0
where py >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:5500
  py -m http.server 5500
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  start "" http://localhost:5500
  python -m http.server 5500
  goto :eof
)
echo Python no esta instalado o no esta agregado al PATH.
pause
